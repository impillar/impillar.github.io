---
title: "Data Structure and Algorithms"
collection: teaching
type: "Undergradaute course"
permalink: /teaching/2010-spring-teaching-2
venue: "Tianjin University, Tianjin"
date: 2010-03-01
location: "Tianjin, China"
---

